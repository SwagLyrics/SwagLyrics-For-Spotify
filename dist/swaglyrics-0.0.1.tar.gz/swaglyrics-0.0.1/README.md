# SwagLyrics-For-Spotify
:fire: Fetches the currently playing song from Spotify and displays the lyrics from Genius on cmd.

Made this mainly for personal use so that I don't sing along with wrong lyrics and end up embarrassing myself later.


Probably wasn't thinking when I put _Swag_ in the name (Imagine if this project ends on my CV) but I'm mainly trying to build this project as far as I can, mainly for practice and to learn stuff.

Main priorities are supporting more songs and making it faster and better. Hopefully an API too so you can get lyrics from wherever.
